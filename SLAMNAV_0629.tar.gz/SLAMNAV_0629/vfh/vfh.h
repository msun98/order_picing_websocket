#ifndef VFH_H
#define VFH_H

#include "global_defines.h"

class VFH
{
public:
    VFH();
    void control(cv::Vec3d cur_pose, cv::Vec3d tgt_pose, std::vector<cv::Vec2d>& cur_scan, double& u_v, double& u_w);

private:    
    cv::Vec3d divXi(cv::Vec3d xi0, cv::Vec3d xi1);
};

#endif // VFH_H
