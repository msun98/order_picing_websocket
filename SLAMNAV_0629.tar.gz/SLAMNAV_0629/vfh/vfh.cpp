#include "vfh.h"

VFH::VFH()
{

}

void VFH::control(cv::Vec3d cur_pose, cv::Vec3d tgt_pose, std::vector<cv::Vec2d>& cur_scan, double& u_v, double& u_w)
{
    // global to local
    cv::Vec3d _tgt_pose = divXi(tgt_pose, cur_pose);
    cv::Vec3d _cur_pose(0,0,0);

    // params
    const int s_max = 10;
    const double threshold = 0.5;
    double tgt_th = std::atan2(_tgt_pose[1], _tgt_pose[0]);

    // make grid
    const double max_dist = 2.0;
    const int l = (max_dist/GRID_WIDTH) + 2;
    const int c = l/2;

    cv::Mat grid(l, l, CV_8U, cv::Scalar(0));
    for(size_t p = 0; p < cur_scan.size(); p++)
    {
        double d = cv::norm(cur_scan[p]);

        /*
        if(d <= ROBOT_RADIUS || d > max_dist)
        {
            continue;
        }
        */

        int u = std::round(cur_scan[p][0] / GRID_WIDTH + c);
        int v = std::round(cur_scan[p][1] / GRID_WIDTH + c);
        if(u < 0 || u >= l || v < 0 || v >= l)
        {
            continue;
        }

        cv::circle(grid, cv::Point(u,v), ROBOT_SAFETY_RADIUS_IN_GRID, cv::Scalar(255), -1);
    }

    // polar histogram
    std::vector<double> polar_hist(360, 0);
    for(int i = 0; i < l; i++)
    {
        for(int j = 0; j < l; j++)
        {
            if(grid.ptr<uchar>(i)[j] == 0)
            {
                continue;
            }

            double x = j-c;
            double y = i-c;
            double th = std::atan2(y, x);
            int idx = (th*R2D) + 180.0;
            idx %= 360;

            double d = std::sqrt(x*x + y*y) * GRID_WIDTH; // meter
            double a = -1.0/(max_dist-ROBOT_SAFETY_RADIUS);
            double b = -a*ROBOT_SAFETY_RADIUS + 1;
            double m = a*d + b; // 0.0~1.0, max_dist -> zero
            if(m > 1)
            {
                m = 1;
            }
            else if(m < 0)
            {
                m = 0;
            }

            if(m > polar_hist[idx])
            {
                polar_hist[idx] = m;
            }
        }
    }

    // select best direction
    int min_idx = 0;
    double min_val = 9999;
    for(size_t p = 0; p < polar_hist.size(); p++)
    {
        if(polar_hist[p] < threshold)
        {
            double th = (double)(p-180)*D2R;
            double dth = std::abs(deltaRad(tgt_th, th));
            if(dth < min_val)
            {
                min_val = dth;
                min_idx = p;
            }
        }
    }

    int k_n = min_idx - 1;
    int k_f = min_idx + 1;
    for (int count = 0; count <= s_max; )
    {
        bool out = false;

        if(k_n < 0)
        {
            k_n += 360;
        }

        if(polar_hist[k_n] < threshold)
        {
            --k_n;
            ++count;
        }
        else
        {
            out = true;
        }

        if(k_f >= 360)
        {
            k_f -= 360;
        }

        if(polar_hist[k_f] < threshold)
        {
            ++k_f;
            ++count;
        }
        else
        {
            if(out)
            {
                break;
            }
        }
    }

    int k_c = (k_n + k_f)/2;

    double steer_direction = (double)(k_c-180)*D2R;
    double steer_magnitude = ROBOT_LIN_VEL_LIMIT*(1.0 - polar_hist[k_c]);
    steer_magnitude = steer_magnitude*(1.0 - std::abs(steer_direction)/ROBOT_ANG_VEL_LIMIT);
    if(steer_magnitude < 0)
    {
        steer_magnitude = 0;
    }

    u_v = steer_magnitude;
    u_w = steer_direction;

    printf("v:%f, w:%f\n", u_v, u_w*R2D);
}

cv::Vec3d VFH::divXi(cv::Vec3d xi0, cv::Vec3d xi1)
{
    cv::Matx22d R1_inv;
    R1_inv(0, 0) = std::cos(xi1[2]);
    R1_inv(0, 1) = std::sin(xi1[2]);
    R1_inv(1, 0) = -std::sin(xi1[2]);
    R1_inv(1, 1) = std::cos(xi1[2]);

    cv::Vec2d t0;
    t0[0] = xi0[0];
    t0[1] = xi0[1];

    cv::Vec2d t1;
    t1[0] = xi1[0];
    t1[1] = xi1[1];

    cv::Vec2d _t = R1_inv * (t0-t1);

    cv::Vec3d xi;
    xi[0] = _t[0];
    xi[1] = _t[1];
    xi[2] = toWrap(xi0[2] - xi1[2]);
    return xi;
}
