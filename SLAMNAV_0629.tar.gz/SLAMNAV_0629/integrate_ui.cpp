#include "integrate_ui.h"
#include <QJsonDocument>
#include <QJsonObject>
INTEGRATE_UI::INTEGRATE_UI(QObject *parent):QObject(parent)
{
    //클라이언트(서버의 주소와 포트를 알고 있어야 함.)
    ui_com = new QTcpSocket();
    IP_UI.ip = "192.168.2.90"; //
    IP_UI.port = 7799;

    connect(ui_com,SIGNAL(connected()),this, SLOT(onUIConnected()));
    //    onUIConnected();
    connect(ui_com,SIGNAL(disconnected()),this, SLOT(onUIdisConnected()));
}

//INTEGRATE_UI::~INTEGRATE_UI()
//{

//}


void INTEGRATE_UI::onUIConnected()
{
    qDebug("connecting........");
    ui_com -> connectToHost(QHostAddress(IP_UI.ip),IP_UI.port);

    connect(ui_com,SIGNAL(readyRead()),this, SLOT(onReadyCmdRead()));
    qDebug()<<"connecting.......";
    if(ui_com ->state()==QAbstractSocket::ConnectedState)
    {
        qDebug("성공이이야야야ㅏㅇ");
    }
    //    onSocketWrite();
}

void INTEGRATE_UI::onReadyCmdRead() //모바일 플랫폼의 상태를 항상 올려받음.
{
    QByteArray Read_Data = ui_com -> readAll();

    QJsonObject json_input;
    json_input = QJsonDocument::fromJson(Read_Data).object();

    if(json_input["MSG_TYPE"] == "STATE"){
        robot_state = json_input["robot_state"].toInt();
        lift_rpm = json_input["lift_rpm"].toInt();
        lift_state = json_input["lift_state"].toString();
        lift_pos = json_input["lift_pose"].toInt();
    }
//    qDebug()<<Read_Data;
}

void INTEGRATE_UI::onUIdisConnected()
{
    onSocketWrite("tcp disconnected");
    qDebug()<<"tcp disconnected";
}

void INTEGRATE_UI::onSocketWrite(QString msg)
{
//    int myint = msg.toInt();
//    QByteArray q_b;
//    q_b.setNum(myint);
//    //    .toUtf8()
    ui_com->write(msg.toUtf8());
//    ui_com->write("ho");
    qDebug()<<msg;
}
