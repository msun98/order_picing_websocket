#ifndef INTEGRATE_UI_H
#define INTEGRATE_UI_H

#include <QObject>
#include <QTcpSocket>
#include <QByteArray>
#include <QHostAddress>

#include "global_defines.h"

class INTEGRATE_UI: public QObject
{
    Q_OBJECT

public:
    explicit INTEGRATE_UI(QObject *parent =nullptr);

    QTcpSocket *ui_com;
    ipInfo IP_UI;

    void onUIConnected();

    void onSocketWrite(QString msg);

    int robot_state = 0;
    int lift_rpm = 0;
    QString lift_state;
    int lift_pos = 0;

public slots:

    void onReadyCmdRead();

    void onUIdisConnected();

};



#endif // INTEGRATE_UI_H
